#Items of list
L = [9,2,1,7,5]
i= 1
#executing loop if length of List L ios greater than i
while i < len(L):
    key = L[i]
    j=i-1
    #executing loop if j is greater than or equal to 0 and key is lesser than L[j]
    while j>= 0 and key < L[j]:
        L[j+1] = L[j]
        j= j - 1
    L[j+1] = key
    i = i +1
#Printing Output
print(L)










