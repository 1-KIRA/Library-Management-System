matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
for row in matrix:
    print(row)
# start here
i = 0
while i < len(matrix):
    j = 0
    while j < len(matrix[i]):
        if i > j:
            matrix[i][j] = 1
        elif i < j:
            matrix[i][j] = -1
        j = j + 1
    i = i + 1
# stop here
print('--------------')

for row in matrix:
    print(row)
