value = input("Enter your value: ")
List = list(value.strip())
for i in range(0,len(List)):
    List[i] = int(List[i])
print ("The sum of the list is : ", sum(List))
print("The maximum number is: " , max(List))
print("The minimum number is: ", min(List))
