str1= input ("Enter First Word: ")
str2= input ("\n Enter Second Word: ")
List=[] 
if(len(str1)<len(str2)): 
    for i in str1: 
        if(i in str2): 
            List.append(i) 
else: 
    for i in str2: 
        if(i in str1): 
            List.append(i) 
print("\nCommon character are:",List)
